# CITY LEVEL PASSENGER TRIP FREQUENCY REPORT

WITH total_repeat_passengers AS (
    SELECT
        d.city_name,
        r.city_id,
        SUM(r.repeat_passenger_count) AS total_repeat_passenger_count
    FROM
        dim_repeat_trip_distribution r
    JOIN
        dim_city d ON r.city_id = d.city_id
    GROUP BY
        d.city_name, r.city_id
),
percentage_distribution AS (
    SELECT
        d.city_name,
        r.trip_count,
        (SUM(r.repeat_passenger_count) * 100.0 /
         SUM(SUM(r.repeat_passenger_count)) OVER (PARTITION BY r.city_id)) AS percentage
    FROM
        dim_repeat_trip_distribution r
    JOIN
        dim_city d ON r.city_id = d.city_id
    GROUP BY
        d.city_name, r.city_id, r.trip_count
)
SELECT
    city_name,
    MAX(CASE WHEN trip_count = '2-Trips' THEN percentage ELSE 0 END) AS "2-Trips",
    MAX(CASE WHEN trip_count = '3-Trips' THEN percentage ELSE 0 END) AS "3-Trips",
    MAX(CASE WHEN trip_count = '4-Trips' THEN percentage ELSE 0 END) AS "4-Trips",
    MAX(CASE WHEN trip_count = '5-Trips' THEN percentage ELSE 0 END) AS "5-Trips",
    MAX(CASE WHEN trip_count = '6-Trips' THEN percentage ELSE 0 END) AS "6-Trips",
    MAX(CASE WHEN trip_count = '7-Trips' THEN percentage ELSE 0 END) AS "7-Trips",
    MAX(CASE WHEN trip_count = '8-Trips' THEN percentage ELSE 0 END) AS "8-Trips",
    MAX(CASE WHEN trip_count = '9-Trips' THEN percentage ELSE 0 END) AS "9-Trips",
    MAX(CASE WHEN trip_count = '10-Trips' THEN percentage ELSE 0 END) AS "10-Trips"
FROM
    percentage_distribution
GROUP BY
    city_name
ORDER BY
    city_name;
