# REPEAT PASSENGER RATE ANALYSIS

SELECT
    md.city_name,
    md.month,
    md.total_passengers,
    md.repeat_passengers,
    ROUND((md.repeat_passengers * 100.0 / md.total_passengers), 2) AS monthly_repeat_passenger_rate,
    ROUND((ctd.total_repeat_passengers * 100.0 / ctd.total_passengers_citywide), 2) AS city_repeat_passenger_rate
FROM
    (
        SELECT
            c.city_name,
            ps.month,
            SUM(ps.total_passengers) AS total_passengers,
            SUM(ps.repeat_passengers) AS repeat_passengers
        FROM
            fact_passenger_summary ps
        JOIN
            dim_city c ON ps.city_id = c.city_id
        GROUP BY
            c.city_name, ps.month
    ) md
JOIN
    (
        SELECT
            c.city_name,
            SUM(ps.total_passengers) AS total_passengers_citywide,
            SUM(ps.repeat_passengers) AS total_repeat_passengers
        FROM
            fact_passenger_summary ps
        JOIN
            dim_city c ON ps.city_id = c.city_id
        GROUP BY
            c.city_name
    ) ctd
ON
    md.city_name = ctd.city_name
ORDER BY
    md.city_name, md.month;

