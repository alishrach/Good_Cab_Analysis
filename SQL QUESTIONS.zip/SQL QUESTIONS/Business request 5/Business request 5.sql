#IDENTIFY MONTH WITH HIGHEST REVENUE FOR EACH CITY

WITH monthly_revenue AS (
    SELECT
        c.city_name,
        dt.start_of_month AS month,
        dt.month_name,
        SUM(ft.fare_amount) AS revenue
    FROM
        fact_trips ft
    JOIN
        dim_city c ON ft.city_id = c.city_id
    JOIN
        dim_date dt ON ft.date = dt.date
    GROUP BY
        c.city_name, dt.start_of_month, dt.month_name
),
city_total_revenue AS (
    SELECT
        city_name,
        SUM(revenue) AS total_revenue
    FROM
        monthly_revenue
    GROUP BY
        city_name
),
ranked_revenue AS (
    SELECT
        mr.city_name,
        mr.month_name AS highest_revenue_month,
        mr.revenue,
        ctr.total_revenue,
        RANK() OVER (PARTITION BY mr.city_name ORDER BY mr.revenue DESC) AS `rank`
    FROM
        monthly_revenue mr
    JOIN
        city_total_revenue ctr ON mr.city_name = ctr.city_name
)
SELECT
    city_name,
    highest_revenue_month,
    revenue,
    ROUND((revenue * 100.0 / total_revenue), 2) AS percentage_contribution
FROM
    ranked_revenue
WHERE
    `rank` = 1
ORDER BY
    city_name;
