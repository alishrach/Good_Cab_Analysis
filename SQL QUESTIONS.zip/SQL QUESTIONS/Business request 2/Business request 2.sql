# MONTHLY CITY LEVEL TRIPS TARGET PERFORMANCE REPORT

SELECT * FROM monthly_target_trips;

SELECT * FROM dim_date;

WITH aggregated_trips AS (
    SELECT 
        f.city_id,
        c.city_name,
        dt.start_of_month AS month,
        dt.month_name,
        COUNT(f.trip_id) AS actual_trips
    FROM 
        trips_db.fact_trips f
    JOIN 
        trips_db.dim_city c ON f.city_id = c.city_id
    JOIN 
        trips_db.dim_date dt ON f.date = dt.date
    GROUP BY 
        f.city_id, c.city_name, dt.start_of_month, dt.month_name
),
performance_report AS (
    SELECT 
        at.city_name,
        at.month_name,
        at.actual_trips,
        mt.total_target_trips AS target_trips,
        CASE 
            WHEN at.actual_trips > mt.total_target_trips THEN 'Above Target'
            ELSE 'Below Target'
        END 
        AS performance_status,
        ROUND(((at.actual_trips - mt.total_target_trips) * 100.0 / mt.total_target_trips), 2) AS percentage_difference
    FROM 
        aggregated_trips at
    JOIN 
        targets_db.monthly_target_trips mt ON at.city_id = mt.city_id AND at.month = mt.month
)
SELECT 
    city_name,
    month_name,
    actual_trips,
    target_trips,
    performance_status,
    percentage_difference AS "%_difference"
FROM 
    performance_report
ORDER BY 
    city_name, month_name;

