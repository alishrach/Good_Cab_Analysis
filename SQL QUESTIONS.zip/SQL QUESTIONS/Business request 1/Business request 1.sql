#CITY LEVEL FARE AND TRIP SUMMARY REPORT

use trips_db;
SELECT * FROM dim_city;
SELECT * FROM fact_trips;

#1)Report that displays the total trips, avg fare per km, avg fare per trip, and the percentage contribution of each city's trips to the overall trips.

WITH city_summary AS (
    SELECT 
        d.city_name, 
        d.city_id,
        COUNT(f.trip_id) AS total_trips, 
        SUM(f.fare_amount) AS total_fare, 
        SUM(f.distance_travelled_km) AS total_distance
    FROM 
        fact_trips AS f
    LEFT JOIN 
        dim_city AS d
    ON 
        d.city_id = f.city_id
    GROUP BY 
        d.city_name, d.city_id
),

#Calculating average fare metrics for each city
city_with_metrics AS (
    SELECT 
        city_name,
        city_id,
        total_trips,
        total_fare,
        total_distance,
        (total_fare / total_distance) AS avg_fare_per_km,
        (total_fare / total_trips) AS avg_fare_per_trip
    FROM 
        city_summary
),

#Calculating percentage contribution to total trips
city_contribution AS (
    SELECT 
        city_name,
        city_id,
        total_trips,
        avg_fare_per_km,
        avg_fare_per_trip,
        (total_trips * 100.0 / SUM(total_trips) OVER()) AS contribution_to_total_trips
    FROM 
        city_with_metrics
)

SELECT 
    city_name,
    city_id,
    total_trips,
    avg_fare_per_km,
    avg_fare_per_trip,
    contribution_to_total_trips
FROM 
    city_contribution
ORDER BY 
    total_trips DESC;
